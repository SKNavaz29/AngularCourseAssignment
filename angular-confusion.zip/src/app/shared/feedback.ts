export class feedback{
    firstname!: string;
    lastname!: string;
    telnum!: number;
    email!: string;
    agree!:boolean;
    contactype!: string;
    message!: string;
};

export const ContactType=['None','Tel','Email'];